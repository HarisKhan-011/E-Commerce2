// Pages/importimages.js
const IMAGES = {
    shirt1: require('../Assets/shirt1.png').default,
    shirt2: require('../Assets/shirt2.png').default,
    shirt3: require('../Assets/shirt3.png').default,
    shirt4: require('../Assets/shirt4.png').default,
    shirt5: require('../Assets/shirt5.png').default,
    shirt6: require('../Assets/shirt6.png').default,
    shirt7: require('../Assets/shirt7.png').default,
    shirt8: require('../Assets/shirt8.png').default,
    shirt9: require('../Assets/shirt9.png').default,
    shirt10: require('../Assets/shirt10.png').default,
};

export default IMAGES;
