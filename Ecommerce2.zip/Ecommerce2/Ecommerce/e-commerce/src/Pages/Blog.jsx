import React from 'react'
import '../Styles/Blog.css'
import Section3 from './Section3'
const Blog = () => {
  return (
    <>
    <div className='blog-main-container'>
    <Section3 />
    </div>
    </>
  )
}

export default Blog